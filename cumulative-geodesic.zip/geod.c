#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#include "defs.h"
#include "geod.h"
#include "heap.h"

int noisemap[bXD][bYD];
int weight[bXD][bYD];
int gradient[bXD][bYD];
#include "screendump.c"
#include "stackoppm.c"
#include "heap.c"
#include "readtex.c"
#include "splatter.c"
#include "bnw.c"


/*----------------------------------------------------------------------*/
void makegraph(void)
{
  // set up 4-connected graph
  int i,j,k,s,t,p;
  edgetype newedge;
  intvector dir[4];
  numnodes = 0;

  dir[0].x = 0;
  dir[0].y = -1;

  dir[1].x = -1;
  dir[1].y = 0;

  dir[2].x = 0;
  dir[2].y = 1;

  dir[3].x = 1;
  dir[3].y = 0;


  for (i = 0; i != XD; i++)
    for (j = 0; j != YD; j++)
      {
	
	pix[numnodes].loc.x = i;
	pix[numnodes].loc.y = j;
	pix[numnodes].id = numnodes;
	pix[numnodes].partcost = 0;
	pix[numnodes].numedges = 0;

	for (k = 0; k != 4; k++)
	  {
	    // mod for tor topo:
	    s = (i + dir[k].x + XD)%XD;
	    t = (j + dir[k].y + YD)%YD;
	    
	    // no special topo
	    s = (i + dir[k].x);
	    t = (j + dir[k].y);

	    if ((s >= 0) && (s < XD) && ( t >= 0) && ( t < YD))
	      {
		p = pix[numnodes].numedges;
		newedge.nearend = j+i*YD;
		newedge.farend = t+s*YD;
		newedge.cost = 4; //+(gradient[i][j]*gradient[s][t])/2;

		// + fabs(dir[k].y)*(rand()%200); -- for preferred crack direx
		pix[numnodes].edges[p] = newedge;
		pix[numnodes].numedges++;
	      }
	  }
	numnodes++;
      }
}
/*----------------------------------------------------------------------*/


int main(int argc, char **argv)
{

  char filenames[6][20] = {"smokepuff",
			   "three-pals",
			   "curly",
			   "barktree",
			   "protest",
			   "cat-mirror"
  };
  char curfile[80];

  int k = 0;
  int masksz = 1280;

  for (int k = 0; k < 6; k++)
    {
       sprintf(curfile,"../../../images/%s.ppm",filenames[k]);
       fprintf(stderr,"Beginning ***%s***\n",filenames[k]);
      fillBACO(readPPM(curfile));

      makegraph();  
      semibilat_color(masksz);

      sprintf(curfile,"results/%s-smooth%i.ppm",
	      filenames[k],masksz);

      output_file(curfile);

      residual_grey();

      sprintf(curfile,"results/%s-res%i.ppm",
	      filenames[k],masksz);

      output_file(curfile);

      residual_abs();
      sprintf(curfile,"results/%s-plainres%i.ppm",
	      filenames[k],masksz);

      output_file(curfile);

      int threshi = 24;
      bnw_thresh(threshi);
      sprintf(curfile,"results/%s-bnw%i-%i.ppm",
	      filenames[k],masksz,threshi);

      output_file(curfile);
    }


}
