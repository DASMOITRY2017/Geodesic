void processmany()
{
  // process a whole bunch of images, trying different parameter values
  // and such

  /* parameters:
     REGION SIZE 10, 20, 40, 80, 160, 320, 640, 1280
     BILATERAL WT 0.1, 0.3. 1, 3, 10

  */

  int possize[8] = {10, 20, 40, 80, 160, 320, 640, 1280};
  int poswt1[5] = {1, 1, 1, 3, 10};
  int poswt2[5] = {10, 3, 1, 1, 1};

  char filenames[6][20] = {"sphinx","old2",
			   "sheep","mountain",
			   "feralcat","model"};

  char curfile[80];
  for (int i = 0; i < 8; i++) // iterate over sizes
    {
      TARGREGSIZE = possize[i];
      //      for (int j = 0; j < 5; j++) // iterate over weights
      {
	int j = 2;
	GEODEWT = poswt1[j];
	CENTRWT = poswt2[j];
	for (int k = 0; k < 6; k++) // iterate over files
	{
	  sprintf(curfile,"../../images/%s.pgm",filenames[k]);
	  loadimage(curfile);
	  semibilat();
	  // now all output
	  sprintf(curfile,"results/%s-smooth-sz%i-a%i-b%i",
		  filenames[k],possize[i],
		  poswt1[j],poswt2[j]);
	  output_file(curfile);

	  showhits();
	  sprintf(curfile,"results/%s-hit-sz%i-a%i-b%i",
		  filenames[k],possize[i],
		  poswt1[j],poswt2[j]);
	  output_file(curfile);

	  showdetailsharpen();
	  sprintf(curfile,"results/%s-exag-sz%i-a%i-b%i",
		  filenames[k],possize[i],
		  poswt1[j],poswt2[j]);
	  output_file(curfile);
	}
      }
    }
}
/*---------------------------------------------------------------------*/
void processmany_color()
{
  // process a whole bunch of images, trying different parameter values
  // and such

  /* parameters:
     REGION SIZE 10, 20, 40, 80, 160, 320, 640, 1280
     BILATERAL WT 0.1, 0.3. 1, 3, 10

  */



  int possize[8] = {10, 20, 40, 80, 160, 320, 640, 1280};
  int poswt1[5] = {1, 1, 1, 3, 10};
  int poswt2[5] = {10, 3, 1, 1, 1};
  float pn[5] = {0, 0.001, 0.01, 0.1, 0.5};
  int ignoren[5] = {0, 2, 5, 10, 20}; // ignore first n

  char filenames[6][20] = {"kyp-desert","kyp-boy",
			   "colorland-part","mountain",
			   "feralcat","model"};
  char curfile[180];

  for (int m = 0; m < 2; m++) // iterate over accum vs noaccum
    for (int n = 0; n < 5; n++) // iterate over ignore n
      for (int p = 0; p < 5; p++) // iterate over exp(-pn)
  for (int i = 4; i < 5; i++) // iterate over sizes
    {
      TARGREGSIZE = possize[i];
      //      for (int j = 0; j < 5; j++) // iterate over weights
      {
	int j = 2;
	GEODEWT = poswt1[j];
	CENTRWT = poswt2[j];
	for (int k = 0; k < 6; k++) // iterate over files
	{
	  sprintf(curfile,"../../images/%s.ppm",filenames[k]);

	  readtex_col_upsidedown(curfile);	  
	  semibilat_color(m%2,ignoren[n],pn[p]);
	  // now all output
	  sprintf(curfile,"results/%s-smooth-sz%i-accum%i-ignore%i-exp%i",
		  filenames[k],possize[i],m,n,p);

	  output_file(curfile);

	  showhits();
	  sprintf(curfile,"results/%s-hit-sz%i-a%i-b%i",
		  filenames[k],possize[i],
		  poswt1[j],poswt2[j]);
	  //	  output_file(curfile); // output hits (for now don't bother)

	  /*
	  showdetailsharpen();
	  sprintf(curfile,"results/%s-exag-sz%i-a%i-b%i",
		  filenames[k],possize[i],
		  poswt1[j],poswt2[j]);
	  output_file(curfile);
	  */
	}
      }
    }
}
/*--------------------------------------------------------------------------*//*---------------------------------------------------------------------*/
void processmany_iter()
{
  // process image iteratively


  char filenames[6][20] = {"kyp-desert","kyp-boy",
			   "colorland-part","mountain",
			   "feralcat","model"};
  char curfile[180];

  fprintf(stderr,"Trying iterative filtering\n");



  GEODEWT = 1.0;
  CENTRWT = 1.0;
  for (int k = 4; k < 5; k++) // iterate over files
    {
      sprintf(curfile,"../../images/%s.ppm",filenames[k]);
      
      readtex_col_upsidedown(curfile);	  
      for (int i = 0; i < 60; i++)
	{

  TARGREGSIZE = 160;
	  iter_color();
	  if ((i < 30) || (i % 5 == 0))
	    {
	      sprintf(curfile,"results/iter%i-%s",
		      i,filenames[k]);
	      
	      output_file(curfile);
	    }
	}

    }
}
/*--------------------------------------------------------------------------*/
void processmany_indicate_xfil()
{
  // indication with n map from another image


  char filenames[8][30] = {"ruins",
			   "sedona",
			   "smokepuff",
			   "roughwater",
			   "barktree",
			   "kittenmirror",
			   "autumn_orange",
			   "argentina"};
			   
  char curfile[180];


  for (int i = 0; i < 7; i++) // iterate over pics
    {

      sprintf(curfile,"../../images/%s.ppm",filenames[i+1]);
      fillBACO(readPPM(curfile));
      indicate_from_baco(255); // default

      sprintf(curfile,"../../images/%s.ppm",filenames[i]);
      fillBACO(readPPM(curfile));
      makegraph_eight();
      
      semibilat_color(1, 0, 0);

      // now all output
      sprintf(curfile,"results/%s-indicate-xfil.ppm",
	      filenames[i]);

      output_file(curfile);
	  
    }
}
/*-------------------------------------------------------------------------*/
/*--------------------------------------------------------------------------*/
void processmany_indicate()
{
  // process a whole bunch of images, trying different indication scenarios

  // possible scenarios: baco-light, baco-dark, baco-grey,
  // upslope, cencirc, GM, LAHE


  char filenames[8][30] = {"ruins",
			   "sedona",
			   "smokepuff",
			   "roughwater",
			   "kittenmirror",
			   "barktree",
			   "autumn_orange",
			   "argentina"};
			   
  char curfile[180];


  for (int i = 6; i < 8; i++) // iterate over pics
    for (int j = 5; j < 7; j++) // iterate over conditions
    {

      sprintf(curfile,"../../images/%s.ppm",filenames[i]);


      fillBACO(readPPM(curfile));
      makegraph_eight();
      indicate_from_baco(128); // default
      if (j == 1)
	indicate_from_baco(0); // dark
      if (j == 2)
	indicate_from_baco(255); // light

      if (j == 3)
	upslope();

      if (j == 4)
	cencirc();
      if (j == 5)
	varyn_lahe(4);
      if (j == 6)
	varyn_lahe(1);
      
      semibilat_color(1, 0, 0);

      // now all output
      sprintf(curfile,"results/%s-indicate-%i.ppm",
	      filenames[i],j);

      output_file(curfile);
	  
    }
}
/*-------------------------------------------------------------------------*/
void processmany_movie()
{

  char curfile[180];

  for (int i = 6184; i < 7150; i++) // iterate over sizes
    {


      //	GEODEWT = 1.0;
      //	CENTRWT = 1.0;

	sprintf(curfile, "../../images/treeseq/frame%.4i.ppm",i);
	  fprintf(stderr,"Loading >>%s<<\n",curfile);
	  fillBACO(readPPM(curfile));
	    makegraph_eight();
      TARGREGSIZE = 240;    
      varyn_flat(240);
	semibilat_color(1, 0, 0.0);
	sprintf(curfile, "results/movie/redone%.4i.ppm",i);
	output_file(curfile);

    }
  exit(0);
}


void processmany_paper()
{
  // results for paper

  int possize[5] = {40, 80, 160, 480, 800};

  int geowt[7] = {1, 1, 1, 10, 100, 1000, 10000};
  int cenwt[7] = {64, 100, 1, 1, 1, 1, 1};

  char filenames[10][60] = {"cliff-foam",
			    "stranger",
			    "haybale",
			    "curly",
			    "barktree",
			    "roughwater",
			    "countryroad",
			    "autumnpark",
			    "sand",
			    "winter"};
  char curfile[280];

  for (int m = 0; m < 1; m++) // iterate over weights
    for (int i = 2; i < 3; i++) // iterate over sizes
      {
	TARGREGSIZE = possize[i];

	for (int k = 0; k < 10; k++) // iterate over files
	  {
	    sprintf(curfile,"../../images/%s.ppm",filenames[k]);
	    readtex_col_upsidedown(curfile);
	    makegraph_eight();
	    GEODEWT = geowt[m];
	    CENTRWT = cenwt[m];
	    semibilat_color(1,0,0.0);
	  // now all output
	  sprintf(curfile,"results/%s-pow2",
		  filenames[k],possize[i],geowt[m],cenwt[m]);

	  output_file(curfile);


	  /*
	  showdetailsharpen();
	  sprintf(curfile,"results/%s-exag-sz%i-a%i-b%i",
		  filenames[k],possize[i],
		  poswt1[j],poswt2[j]);
	  output_file(curfile);
	  */
	  }
      }

}
void processmany_flat()
{
  // results for paper

    int possize[3] = {40, 100, 400};
    //int possize[3] = {128, 200, 300};

  char filenames[13][60] = {    
                           "argentina",
			   "winter",
			   "countryroad",
			   "brick",
			   "haybale",
			   "barktree",
			   "smokepuff",
			   "autumn-orange",
			   "protest",
			    "ruins",
			    "roughwater",
			    "kittenmirror",
			   "sedona"};
  char curfile[280];

    for (int i = 0; i < 3; i++) // iterate over sizes
      {
	TARGREGSIZE = possize[i];

	for (int k = 1; k < 3; k++) // iterate over files
	  {
	    sprintf(curfile,"../../images/%s.ppm",filenames[k]);
	    fillBACO(readPPM(curfile));

	    makegraph_eight();
	    varyn_flat(possize[i]);
	    semibilat_color(1,0, 0);
	  // now all output
	  sprintf(curfile,"results/%s-flat-%i.ppm",
		  filenames[k],possize[i]);

	  output_file(curfile);

	  }
      }

}
void processmany_compare()
{
  // results for paper -- comparisons

  int possize[5] = {40, 80, 160, 480, 800};


  char filenames[4][60] = {"orzan-flower",
			    "crim-weiss",
			   "kyp-desert",
			    "kyp-cat"};
  char curfile[280];



  TARGREGSIZE = 160; // standard size

  for (int k = 0; k < 4; k++) // iterate over files
    {
      sprintf(curfile,"../../images/compare/%s-orig.ppm",filenames[k]);
      readtex_col_upsidedown(curfile);
      makegraph_eight();
      GEODEWT = 1;
      CENTRWT = 1;
      semibilat_color(1,0,0.0);

      sprintf(curfile,"results/%s-compare-sz%i",
	      filenames[k],TARGREGSIZE);

      output_file(curfile);

    }


}

void processmany_bilat()
{
  // bilateral results for paper


  float dwt[5] = {0.0001, 0.00003, 0.00001, 0.000003, 0.000001};
  float cwt[5] = {0.0001, 0.00003, 0.00001, 0.000003, 0.000001};

  float gammas, gammad;

  char filenames[10][60] = {"cliff-foam",
			    "stranger",
			    "curly",
			    "barktree",
			    "haybale",
			    "roughwater",
			    "countryroad",
			    "autumnpark-crop",
			    "sand",
			    "winter"};
  char curfile[280];

  for (int m = 0; m < 5; m++) // iterate over spatial
    for (int i = 0; i < 5; i++) // iterate over color
      {
	gammas = dwt[m];
	gammad = cwt[i];

	for (int k = 7; k < 8; k++) // iterate over files
	  {
	    sprintf(curfile,"../../images/%s.ppm",filenames[k]);
	    readtex_col_upsidedown(curfile);
	    makegraph_eight();

	    bilateral_color(gammas, gammad);


	  // now all output
	  sprintf(curfile,"bilat/%s-bilat-spat%i-col%i",
		  filenames[k],m,i);

	  output_file(curfile);

	  }
      }

}

void processmany_xfilter()
{
  // bilateral examples


  float gammas, gammad;

  char images[5][60] = {"cliff-foam",
			"stranger",
			"curly",
			"barktree",
			"autumnpark-crop"};

  char textures[5][60] = {"xfil-grass",
			   "xfil-foliage2",
			   "xfil-gravel",
			   "xfil-panel",
			   "xfil-leaves"};
  char curfile[280];

  for (int m = 1; m < 4; m++) // iterate over images
    for (int i = 1; i < 4; i++) // iterate over texture
      {
	
	sprintf(curfile,"../../images/%s.ppm",images[m]);
	readtex_col_upsidedown(curfile);
	makegraph_eight();
	baco_aside();
	showbaco();
	int savex = XD;
	int savey = YD;
	sprintf(curfile,"texture/%s.ppm",textures[i]);
	readtex_col_upsidedown(curfile);
	XD = savex;
	YD = savey;
	TARGREGSIZE = 180;
	semibilat_color_xfilter(1,1.0,0.0);

	sprintf(curfile,"results/%s-%s-purex.ppm",
		images[m],textures[i]);

	output_file(curfile);

      }
  
  exit(0);

}
/*---------------------------------------------------------------------*/
void makenoise_flat(int range)
{
  int lev, xt, yt;
  XD = 128;
  YD = 128;
  for (int i = 0; i < XD; i++)
    for (int j = 0; j < YD; j++)
      {
	xt = i/8;
	yt = j/8;

	if (xt+yt % 2 == 0)
	  orig[j][i] = 64;
	else
	  orig[j][i] = 192;
	lev = orig[j][i] + (rand() % (2*range+1)) - range;
	BACO[i][j].red = lev;
	BACO[i][j].green = lev;
	BACO[i][j].blue = lev;
      }
}
/*---------------------------------------------------------------------*/
/*---------------------------------------------------------------------*/
void processmany_dist()
{
  char curfile[280];
  char filenames[18][30] = {
			   "countryroad",
			   "winter",
			   "brick",
			    "ruins",
			   "sedona",
			   "kittenmirror",
			   "roughwater",
			   "haybale",
			   "autumnpark",
			   "barktree",
			   "smokepuff",
			   "autumn_orange",
			   "argentina",
			   "cliff-foam",
			   "stranger",
			   "curly",
			   "roughwater",
			   "sand"};

  int testmax[] = {40,80,160,320,640};

  for (int j = 0; j < 3; j++) // files
    //    for (int i = 3; i < 4; i++) // distances
      {
	MAXDIST = 100; //testmax[i];
	sprintf(curfile,"../../images/%s.ppm",filenames[j]);
	fillBACO(readPPM(curfile));
	makegraph_eight();
	CHECKSIZE = 40;
	THEAV = findav(CHECKSIZE);
	semibilat_color_stopdist(1, 0, 0);

      // now all output
	sprintf(curfile,"results/%s-maxdist-%i-Nov23-0.8-%i.ppm",
		filenames[j],CHECKSIZE,MAXDIST);
	
	output_file(curfile);

    }
}
/*---------------------------------------------------------------------*/
void processmany_allbig()
{
  char curfile[280];
  char filenames[8][30] = {"ruins",
			   "sedona",
			   "smokepuff",
			   "roughwater",
			   "barktree",
			   "kittenmirror",
			   "autumn_orange",
			   "argentina"};



  for (int j = 0; j < 8; j++) // files
    {
      TARGREGSIZE = 550; // all processed with big mask
      sprintf(curfile,"../../images/%s.ppm",filenames[j]);
      fillBACO(readPPM(curfile));
      makegraph_eight();
      
      semibilat_color(1, 0, 0);

      // now all output
	sprintf(curfile,"results/%s-mask-550.ppm",
		filenames[j]);
	
	output_file(curfile);

    }
}
/*---------------------------------------------------------------------*/
void processmany_noise()
{
  // process noise examples with different mask sizes

  char curfile[280];

  int testregsize[] = {40,80,160,320};
  
  float before;

  for (int i = 90; i <= 90; i++)
    {
      makenoise_flat(20);
      makegraph_eight();
      baco_aside();
      showbaco();
      before = rms_flat();
      TARGREGSIZE = i*5;

      semibilat_color(1,1.0,0.0);
      fprintf(stderr,"Processed %i with semi\n",i);

      fprintf(stdout,"%i %.2lf %.2lf\n",TARGREGSIZE,before, rms_flat() );

    }
  
  exit(0);
}
/*---------------------------------------------------------------------*/

/*---------------------------------------------------------------------*/
void processmany_noiselevels()
{
  // process noise examples with different noise levels

  char curfile[280];

  int testregsize[] = {40,80,160,320};
  float before;
  float after_semi, after_box;

  for (int i = 2; i < 32; i++)
    {
      makenoise_flat(i*4);
      makegraph_eight();
      baco_aside();
      showbaco();
      TARGREGSIZE = 169;
      before = rms_flat();
      semibilat_color(1,1.0,0.0);
      
      after_semi = rms_flat();
      boxfilter(6);
      after_box = rms_flat();
      fprintf(stdout,"%i %.2lf %.2lf %.2lf\n",i*4,before,after_box,after_semi);

    }
  
  exit(0);
}


