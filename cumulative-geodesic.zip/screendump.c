void output(int time)
{
  /* Writes contents of array screen[][] to ppm file.*/
  int i,j;
  float er;
  char filename[80];
  FILE *mydest;
  rgbvector m[YD][XD];

  for (i = 0; i != XD; i++)
    for (j = 0; j != YD; j++)
      {
	m[YD-1-j][i] = screen[j][i];
      }


  sprintf(filename,"scratch/heat%.3lf.ppm",
	  (float)(time/1000.));

  mydest = fopen(filename,"w");

  fprintf(mydest,"P6\n%i %i\n255\n",XD,YD);

  fwrite(&m,1,XD*YD*3,mydest);
  
  fclose(mydest);
}

void output_file(char *filename)
{
  /* Writes contents of array screen[][] to ppm file.*/
  
  fprintf(stderr,"Beginning to write file...\n");

int i,j;
  float er;

  FILE *mydest;
  rgbvector m[YD][XD];

  fprintf(stderr,"Created space, now revert from upside down...\n");

  for (i = 0; i != XD; i++)
    for (j = 0; j != YD; j++)
      {
	m[YD-1-j][i] = screen[j][i];
      }

  fprintf(stderr,"Writing...\n");
  mydest = fopen(filename,"w");

  fprintf(mydest,"P6\n%i %i\n255\n",XD,YD);

  fwrite(&m,1,XD*YD*3,mydest);
  
  fclose(mydest);
  fprintf(stderr,"Writing complete.\n");
}
