// A trivial bnw idea

void bnw_thresh(float thresh)
{
  // compute a black and white image by adding the thresholded black and white image
  // to the three-way-thresholded residual.

  float diff, inten;
  float s;
  float BNWTHRESH = thresh;

  for (int i = 0; i < YD; i++)
    for (int j = 0; j < XD; j++)
      {
	inten = (postfilter_c[i][j].red + 
		 postfilter_c[i][j].green +
		 postfilter_c[i][j].blue)/3;

        diff = (BACO[i][j].red - postfilter_c[i][j].red) +
          (BACO[i][j].green - postfilter_c[i][j].green) +
          (BACO[i][j].blue - postfilter_c[i][j].blue);

	if (fabs(diff) > BNWTHRESH)
	  {
	    // use what's in the difference
	    if (diff > 0) s = 255;
	    else s = 0;
	  }
	else
	  {
	    // use what's in original
	    if (inten > 128) s = 255;
	    else s = 0;
	  }

        if (s < 0) s = 0;
        if (s > 255) s = 255;

        screen[i][j].red = s;
        screen[i][j].green = s;
        screen[i][j].blue = s;

      }

}
