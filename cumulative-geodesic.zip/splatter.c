#define SUCCEED 0
#define FAILED -99

#define  MINSIZE 15
#define MINSIZE2 40

#define ROISIZE 1801

double distance[ROISIZE][ROISIZE];
int touched[ROISIZE][ROISIZE];
int curtouch = 0;

#define MAX(X,Y) ((X) < (Y) ? (Y) : (X))

/*------------------------------------------------------------------------*/
void setup()
{
  curtouch = 0;
  for (int i = 0; i < ROISIZE; i++)
    for (int j = 0; j < ROISIZE; j++)
      {
	touched[i][j] = curtouch;
      }
}
/*------------------------------------------------------------------------*/
int coldist(rgbvector one, rgbvector two)
{
  int retval;

  int onein, twoin;

  retval = (int)sqrt(
		     (one.red-two.red)*(one.red-two.red) + 
		     (one.green-two.green)*(one.green-two.green) + 
		     (one.blue-two.blue)*(one.blue-two.blue)
		 );
 
  return(retval);
}
/*---------------------------------------------------------------------------*/
rgbvector semibilat_process(int curcen, int TARGREGSIZE)
{
  // find filter output starting at graph node curcen


  heaptype heap;
  int regsize;

  int mycost;
  strippednode sn, newnode;

  double totred = 0;
  double totgreen = 0;
  double totblue = 0;
  int s,t,d;
  int i,j,p,q,x,y;
  int sx_loc, sy_loc;
  int tx_loc, ty_loc;

  rgbvector neighcol, origcol, herecol, retval;



  emptyheap(&heap);

  p = pix[curcen].loc.y;
  q = pix[curcen].loc.x;
  
  origcol.red = BACO[p][q].red;
  origcol.green = BACO[p][q].green;
  origcol.blue = BACO[p][q].blue;
  
  sn.id = curcen;
  sn.distance = 0;
  distance[q][p] = 0; // note reversed coordinates, aargh
  touched[q][p] = curtouch;
  insertintoheap(sn, &heap);

  regsize = 0;
  
  totred = 0;
  totgreen = 0;
  totblue = 0;
    
  while (regsize < TARGREGSIZE) // continue until big enough region
    {

      sn = maxfromheap(&heap);
      s = sn.id;
      
      sx_loc = pix[s].loc.x;
      sy_loc =  pix[s].loc.y;
      // sx, sy local coordinates of current pixel
      
      if (sn.distance == distance[sx_loc][sy_loc]) 
	// verify that it's not a zombie
	{
	  // this node is good, pix[s] can become part of current region
	    
	  p = pix[s].loc.y;
	  q = pix[s].loc.x;
	  
	  herecol.red = BACO[p][q].red;
	  herecol.green = BACO[p][q].green;
	  herecol.blue = BACO[p][q].blue;
	  
	  totred += BACO[p][q].red;
	  totblue += BACO[p][q].blue;
	  totgreen += BACO[p][q].green;

	  // increment region size
	  regsize++;

	  // run through all neighbours and add to heap:
	  for (j = 0; j != pix[s].numedges; j++)
	    {
	      t = pix[s].edges[j].farend;
	      tx_loc = pix[t].loc.x;
	      ty_loc = pix[t].loc.y;
	      // tx,ty local coordinates of neighbour

	      if ((tx_loc < 0) || (ty_loc < 0) ||
		  (tx_loc >= ROISIZE) || (ty_loc >= ROISIZE))
		{
		  // out of bounds, shouldn't happen
		  fprintf(stderr,"Reached outside ROI\n");
		  
		}
	      else
		{
		  // in bounds, can proceed
		  neighcol.red = BACO[pix[t].loc.y][pix[t].loc.x].red;
		  neighcol.green = BACO[pix[t].loc.y][pix[t].loc.x].green;
		  neighcol.blue = BACO[pix[t].loc.y][pix[t].loc.x].blue;
		  
		  mycost = distance[sx_loc][sy_loc] +  // old cost
		    // plus range cost:
		    coldist(origcol,neighcol) + 1;
		  // +1 to approximate spatial cost
		  
		  if (
		      (mycost < distance[tx_loc][ty_loc]) // better path? 
		      || (touched[tx_loc][ty_loc] != curtouch) // up to date distance value?
		      )
		    {		
		      // it is better, so update, insert into heap
		      distance[tx_loc][ty_loc] = mycost;
		      touched[tx_loc][ty_loc] = curtouch;
		      newnode.id = t;
		      newnode.distance = mycost;
		      insertintoheap(newnode, &heap);
		    }
		  else
		    {
		      // node was rejected, do nothing
	
		    }
		}
	    }
	}      
      
    } // end "big enough region"
  
      // now, region completed, compute average color and return
  
  retval.red = (int)(totred/regsize);
  retval.green = (int)(totgreen/regsize);
  retval.blue = (int)(totblue/regsize);

  return retval;
}
/*---------------------------------------------------------------------------*/
void semibilat_color(int accum)
{

  int i,p,q;

  rgbvector filterout;

  // initialization pass here:

  setup();

  for (i = 0; i < XD*YD; i++)
    {

      pix[i].regionid = -50;
      pix[i].partcost = XD*YD;

    }

  for (i = 0; i < XD*YD; i++) 
    {
      // start a new building process centred on current pixel
      if (i % 10000 == 1) // progress meter to console
	{
	  fprintf(stderr,"progress %i, mask %i\n", i-1, accum);
	}
      curtouch++;
      filterout = semibilat_process(i,accum); // filter pixel i
      p = pix[i].loc.y;
      q = pix[i].loc.x;

      postfilter_c[p][q] = filterout;
      screen[p][q] = postfilter_c[p][q];

    }

  fprintf(stderr,"All done!\n");
}
/*---------------------------------------------------------------------------*/
void residual_grey(void)
{
  // compute difference between filtered and original, produce visualization

  // display exaggerated difference plus 128

  int s;
  int diff;

  for (int i = 0; i < YD; i++)
    for (int j = 0; j < XD; j++)
      {
	diff = (BACO[i][j].red - postfilter_c[i][j].red) +
	  (BACO[i][j].green - postfilter_c[i][j].green) +
	  (BACO[i][j].blue - postfilter_c[i][j].blue);

	s = 128 + diff; // 3*exaggeration built in, could be enough
	
	if (s < 0) s = 0;
	if (s > 255) s = 255;

	screen[i][j].red = s;
	screen[i][j].green = s;
	screen[i][j].blue = s;


      }
  
}
/*---------------------------------------------------------------------------*/
void residual_save(void)
{
  // save residual

  int s;
  int diff;

  for (int i = 0; i < YD; i++)
    for (int j = 0; j < XD; j++)
      {
	residual[i][j].red = (BACO[i][j].red - postfilter_c[i][j].red);
	residual[i][j].green = (BACO[i][j].green - postfilter_c[i][j].green);
	residual[i][j].blue = (BACO[i][j].blue - postfilter_c[i][j].blue);
      }
}
/*---------------------------------------------------------------------------*/
void residual_abs(void)
{
  // another residual visualization

  int s;
  int diff;

  for (int i = 0; i < YD; i++)
    for (int j = 0; j < XD; j++)
      {
	diff = (BACO[i][j].red - postfilter_c[i][j].red) +
	  (BACO[i][j].green - postfilter_c[i][j].green) +
	  (BACO[i][j].blue - postfilter_c[i][j].blue);

	s = (int)fabs((float)diff);
	s = s*3 - 20;

	s = 255 - s; // black residual on white background

	if (s < 0) s = 0;
	if (s > 255) s = 255;

	screen[i][j].red = s;
	screen[i][j].green = s;
	screen[i][j].blue = s;


      }
  
}
/*---------------------------------------------------------------------------*/







