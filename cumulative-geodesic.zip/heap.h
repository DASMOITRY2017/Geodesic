
/*
#ifndef XD
#define XD 300
#define YD 300
#endif
*/

#define BLEH 7

#define BIGNUM 320001

typedef struct {
  long int distance;
  long int temp;
  int id;
} strippednode;


typedef struct {
  strippednode entry[400*BLEH];
  int numentries;
  int cutoff;
} heaptype;

