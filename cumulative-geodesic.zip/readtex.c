
int actx, acty;

/*--------------------------------------------------------------------------*/
void resettle(void)
{
  int i,j;
  if (acty > YD)
    for (i = 0; i != YD; i++)
      {
	for (j = 0; j != XD; j++)
	  {
	    BACO[i][j] = BACO[i+(acty-YD)][j];
	    BASE[i][j] = BASE[i+(acty-YD)][j];
	  }
      }
}
/*--------------------------------------------------------------------------*/
void readtex_upsidedown(const char *filename)
{
  /* Code to load PPMs.
     The file will start
     P5
     XSIZE YSIZE
     255
     data stream...
  */

  unsigned char tex[2048576];

  int INX = 0;
  int INY = 0;
  
  int i,j;

  int xsz,ysz;

  int checks;
  
  FILE *mydest;

  mydest = fopen(filename,"r");

  if (mydest != NULL)
    {
      fscanf(mydest,"P5\n");

      fscanf(mydest,"%i %i\n",&xsz,&ysz);

      actx = xsz; XD = xsz;
      acty = ysz; YD = ysz;

      fscanf(mydest,"255\n");

      checks = fread(&tex,1,xsz*ysz,mydest);
      fprintf(stderr,"Read %i elements - %i by %i.\n",checks,xsz,ysz);
      fclose(mydest);
      for (i = 0; i != ysz; i++)
	{
	  for (j = 0; j != xsz; j++)
	    {
	      //	      BASE[ysz-i-1][j] = tex[(i+INX)*xsz+j+INY];
	      BASE[ysz-i-1][j] = tex[(i+INY)*xsz+j+INX];
	      //	  BASE[ysz-i-1][j] = 255*(j/(xsz+0.0));
	      /* TODOO
	      if (BASE[i][j] == 0)
		fprintf(stderr,"Zero at %i %i\n",i,j);
	      */
	    }
	}
    }
  else
    {
      fprintf(stderr,"File %s not found - no data read.\n",
	      filename);
     }

}

/*--------------------------------------------------------------------------*/

void readtex(const char *filename)
{
  unsigned char tex[1048576];

  int INX = 0;
  int INY = 0;
  
  int i,j;

  int xsz,ysz;

  int checks;
  
  FILE *mydest;

  mydest = fopen(filename,"r");

  if (mydest != NULL)
    {
      fscanf(mydest,"P5\n");

      /*      fscanf(mydest,"# %[^\n]");
	      fscanf(mydest,"# %[^\n]"); */
      /* allows two lines of comments */
      /* but that code doesn't work */

      fscanf(mydest,"%i %i\n",&xsz,&ysz);

      actx = xsz; XD = xsz;
      acty = ysz; YD = ysz;

      fscanf(mydest,"255\n");

      checks = fread(&tex,1,xsz*ysz,mydest);
      fprintf(stderr,"Read %i elements - %i by %i.\n",checks,xsz,ysz);
      fclose(mydest);
      for (i = 0; i != ysz; i++)
	{
	  for (j = 0; j != xsz; j++)
	    {
	      BASE[i][j] = tex[(i+INX)*xsz+j+INY];
	      /*
	      if (BASE[i][j] == 0)
		fprintf(stderr,"Zero at %i %i\n",i,j);
	      */
	    }
	}
    }
  else
    {
      fprintf(stderr,"File %s not found - no data read.\n",
	      filename);
     }

}

void readtex_col_upsidedown(const char *filename)
{

  int INX = 0;
  int INY = 0;

  rgbvector tex[2048576];

  int i,j;

  int xsz,ysz;

  int checks;
  
  FILE *mydest;

  mydest = fopen(filename,"r");

  if (mydest != NULL)
    {
      fscanf(mydest,"P6\n");

      fscanf(mydest,"%i %i\n",&xsz,&ysz);

      actx = xsz; XD = xsz;
      acty = ysz; YD = ysz;

      fscanf(mydest,"255\n");

      checks = fread(&tex,3,xsz*ysz,mydest);
      fprintf(stderr,"Read %i elements - %i by %i.\n",checks,xsz,ysz);
      fclose(mydest);

      for (i = 0; i != ysz; i++)
	{
	  for (j = 0; j != xsz; j++)
	    {
	      BACO[ysz-1-i][j] = tex[(i+INX)*xsz+j+INY];
	      /*	      if (rand()%5000 == 0)
		{
		  fprintf(stderr,"%i %i %i\n",
			  BACO[i][j].red,
			  BACO[i][j].green,
			  BACO[i][j].blue);
			  } */
	      /*
	      if (BASE[i][j] == 0)
		fprintf(stderr,"Zero at %i %i\n",i,j);
	      */
	    }
	}
    }
  else
    {
      fprintf(stderr,"File %s not found - no data read.\n",
	      filename);
     }

}
/*--------------------------------------------------------------------------*/
void readtex_col(const char *filename)
{
  /* imagine that it's a PGM. That's the sensible thing, no?
     Then it will start
     P5
     # some comments here
     XSIZE YSIZE
     255
     data stream...
  */

  int INX = 0;
  int INY = 0;

  rgbvector tex[2048576];

  int i,j;

  int xsz,ysz;

  int checks;
  
  FILE *mydest;

  mydest = fopen(filename,"r");

  if (mydest != NULL)
    {
      fscanf(mydest,"P6\n");

      fscanf(mydest,"%i %i\n",&xsz,&ysz);

      actx = xsz;
      acty = ysz;

      fscanf(mydest,"255\n");

      checks = fread(&tex,3,xsz*ysz,mydest);
      fprintf(stderr,"Read %i elements - %i by %i.\n",checks,xsz,ysz);
      fclose(mydest);

      for (i = 0; i != ysz; i++)
	{
	  for (j = 0; j != xsz; j++)
	    {
	      BACO[i][j] = tex[(i+INX)*xsz+j+INY];
	      if (rand()%5000 == 0)
		{
		  fprintf(stderr,"%i %i %i\n",
			  BACO[i][j].red,
			  BACO[i][j].green,
			  BACO[i][j].blue);
		}
	      /*
	      if (BASE[i][j] == 0)
		fprintf(stderr,"Zero at %i %i\n",i,j);
	      */
	    }
	}
    }
  else
    {
      fprintf(stderr,"File %s not found - no data read.\n",
	      filename);
     }

}
/*--------------------------------------------------------------------------*/
void writetex(const char *filename)
{
  /* write screen to filename */
  FILE *mydest;
  int i,j;

  rgbvector sliver[YD][XD];

  for (i = 0; i != YD; i++)
    for (j = 0; j != XD; j++)
      sliver[i][j] = screen[i][j];

  mydest = fopen(filename,"w");
  
  fprintf(mydest,"P6\n%i %i\n255\n",XD,YD);

  fwrite(&(sliver),1,XD*YD*3,mydest); /* the who-o-ole screen! */
  
  fclose(mydest);
}


