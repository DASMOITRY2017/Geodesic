#define bXD 1800
#define bYD 1800
#define MAXPATHLEN 512


int XD = 512;
int YD = 512;

typedef struct {
  int nearend;
  int farend;
  int cost;
} edgetype;



typedef struct {
  intvector loc;
  int id;
  int partcost;
  int dist;
  int regionid;
  edgetype edges[9];
  int whichpass;
  int numedges;
  
} nodetype;


nodetype pix[bXD*bYD];
int numnodes = 0;

rgbvector screen[bXD][bYD];


int BASE[5][5]; //[bXD][bYD];
rgbvector postfilter_c[bXD][bYD];

#define NOTEXIST -99

rgbvector BACO[bXD][bYD];
rgbvector residual[bXD][bYD];

void makegraph(void);

void processmany(void);

//int TARGREGSIZE = 40;
